# Evidence-Weighted Supplement Titration Framework

## The Problem

Consumer nutrigenomics follows a binary logic:

```
Genotype detected → Supplement recommended
```

This ignores:
1. Is the genetic predisposition actually *expressing* in the patient?
2. How strong is the evidence that supplementation helps carriers specifically?
3. Are there contraindications with current medications or biomarker levels?

## The Framework

For each gene-supplement pair, evaluate:

### A. Biological Plausibility (1-10)
Is the biochemical mechanism well-characterized?

### B. Effect Size
What percentage of trait variance does this variant explain?
- >5%: Clinically meaningful
- 1-5%: Detectable but modest
- <1%: Negligible in isolation

### C. Penetrance
What fraction of carriers actually express the phenotype?

### D. Expression Status (the key innovation)
Cross-reference genotype against available phenotypic data:

| Data Source | What It Tells You |
|---|---|
| Blood biomarkers | Is the pathway functionally impaired? |
| Wearable biometrics | Is there physiological stress or dysfunction? |
| Symptoms | Does the patient experience the predicted phenotype? |
| Body composition | Is the metabolic consequence visible? |

### E. Intervention Evidence
Are there RCTs specifically in variant carriers? Or is efficacy extrapolated from the general population?

### F. Classification

**DIAL UP** → Genotype predicts risk AND biomarkers confirm dysfunction AND RCT evidence supports supplementation in carriers

**MAINTAIN** → Genotype predicts risk, biomarker data is ambiguous, general evidence supports supplementation

**DIAL DOWN** → Genotype predicts risk BUT no phenotypic evidence of expression

**SKIP** → Weak genetic evidence OR no phenotypic expression OR the genotype was misclassified

**CONTRAINDICATED** → Supplementation would worsen the patient's current physiological state (e.g., cortisol-lowering supplements when cortisol is already suppressed)
