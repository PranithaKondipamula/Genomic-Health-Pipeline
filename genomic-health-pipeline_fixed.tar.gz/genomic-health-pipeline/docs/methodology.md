# Mathematical Methodology

## Disease Risk Estimation Pipeline

### Population Normalization

Without normalization, the multiplicative OR model systematically overestimates risk because the "average" genotype at each locus produces an OR slightly above 1.0. We normalize using minor allele frequencies:

```
Mean_log_OR = Σ (2 × MAF_i × log(OR_het_i))
log(OR_normalized) = log(OR_individual) - Mean_log_OR
```

This ensures a person with population-average genotypes receives exactly the population base rate.

### OR to Relative Risk Conversion

For common diseases (base rate > 10%), raw odds ratios overestimate relative risk:

```
RR = OR / (1 - P₀ + P₀ × OR)
```

This prevents the mathematical impossibility of absolute risk exceeding 100%.

### Age Attenuation

Genetic effects on disease risk weaken with age (Mostafavi et al.):

```
log(OR_attenuated) = log(OR) × attenuation_factor(age)
```

Attenuation factors: <45: 1.00, 45-54: 0.95, 55-64: 0.85, 65-74: 0.70, 75+: 0.55

### Gene-Gene Interaction Overrides

When two SNPs produce a non-additive combined effect (e.g., Factor V Leiden + Prothrombin G20210A with super-multiplicative OR = 20), their individual ORs are REPLACED with the empirically measured combined OR.

### Confidence Interval Scaling

CI width scales with SNP coverage — diseases where fewer variants were found receive wider intervals:

```
uncertainty = max(0.20, 1.0 - coverage_ratio)
CI_bounds = OR × (1 ± uncertainty)
```

## Longitudinal Biomarker Analysis

Uses weighted least squares regression where each blood draw is weighted inversely by a composite confounder score:

```
confounder_score = travel × 0.4 + pollution_zscore × 0.3 + sleep_deficit_zscore × 0.2 + stress × 0.1
weight = 1 - confounder_score
```

This down-weights draws taken during travel, high pollution exposure, or acute stress periods.

## Ancestry-Stratified Rarity Scoring

Hardy-Weinberg genotype frequencies using ancestry-specific MAFs from gnomAD v4:

```
P(homozygous risk) = q²
P(heterozygous) = 2pq
P(homozygous reference) = p²
```

Where q = risk allele frequency in the relevant ancestry subpopulation.
